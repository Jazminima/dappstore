/**
 * API Handler for MINIVOX transactions
 */

// Note: SchemaConverter is loaded by service.js
MDS.log("apihandler.js: Initializing API Handler");
var ApiHandler = {
  handleRequest: function (msg) {
    MDS.log("apihandler.js: Handling new API request");
    try {
      const entry = JSON.parse(msg.data.message);
      
      // Log incoming request
      MDS.log("apihandler.js: Parsed entry: " + JSON.stringify(entry, null, 2));
      MDS.log("apihandler.js: Entry type: " + entry.entryType);

      if (!entry || !entry.entryType) {
        throw new Error("Invalid schema: missing entryType");
      }

      // Convert entry to legacy format based on type
      let legacyParams;
      MDS.log("apihandler.js: Converting to legacy format for type: " + entry.entryType);
      
      switch(entry.entryType) {
        case 'post':
        case 'article':
        case 'reply':
          MDS.log("apihandler.js: Converting message to legacy format");
          legacyParams = SchemaConverter.convertMessageToLegacy(entry);
          MDS.log("apihandler.js: Legacy params for message: " + JSON.stringify(legacyParams, null, 2));
          this.sendMessage(legacyParams, this.createCallback(msg, entry.entryType));
          break;

        case 'vote':
          MDS.log("apihandler.js: Converting vote to legacy format");
          legacyParams = SchemaConverter.convertTipToLegacy(entry);
          MDS.log("apihandler.js: Legacy params for vote: " + JSON.stringify(legacyParams, null, 2));
          this.sendTip(legacyParams, this.createCallback(msg, entry.entryType));
          break;

        case 'payment':
          MDS.log("apihandler.js: Converting payment to legacy format");
          legacyParams = SchemaConverter.convertTipToLegacy(entry);
          MDS.log("apihandler.js: Legacy params for payment: " + JSON.stringify(legacyParams, null, 2));
          this.sendPayment(legacyParams, this.createCallback(msg, entry.entryType));
          break;

        case 'poll':
          MDS.log("apihandler.js: Converting poll to legacy format");
          legacyParams = SchemaConverter.convertPollToLegacy(entry);
          MDS.log("apihandler.js: Legacy params for poll: " + JSON.stringify(legacyParams, null, 2));
          this.sendPoll(legacyParams, this.createCallback(msg, entry.entryType));
          break;

        case 'poll_vote':
          MDS.log("apihandler.js: Converting poll vote to legacy format");
          legacyParams = SchemaConverter.convertPollVoteToLegacy(entry);
          MDS.log("apihandler.js: Legacy params for poll vote: " + JSON.stringify(legacyParams, null, 2));
          this.sendPollVote(legacyParams, this.createCallback(msg, entry.entryType));
          break;

        case 'read_message':
        case 'read_tip':
        case 'read_poll':
        case 'read_poll_vote':
        case 'read_payment':
          MDS.log("apihandler.js: Processing read operation for: " + entry.entryType);
          this.readCoin(entry, this.createCallback(msg, entry.entryType));
          break;

        default:
          throw new Error("Unsupported entry type: " + entry.entryType);
      }
    } catch (error) {
      MDS.log("apihandler.js: Error processing request - " + (error.stack || error.message));
      MDS.api.reply(
        msg.data.from,
        msg.data.id,
        JSON.stringify({
          status: false,
          error: error.message,
        })
      );
    }
  },

  // Helper function to create response callback
  createCallback: function(msg, entryType) {
    return function(response) {
      MDS.log("apihandler.js: Processing callback for type: " + entryType);
      MDS.log("apihandler.js: Raw response: " + JSON.stringify(response, null, 2));
      
      // Extract the core type without the read_ prefix if it exists
      const coreType = entryType.replace('read_', '');
      MDS.log("apihandler.js: Core type: " + coreType);

      // Check if the response is in error state
      if (!response) {
        MDS.log("apihandler.js: Response in error state or empty");
        // If the response includes data, we might still be able to convert it
        const errorData = response;
        MDS.log("apihandler.js: Error data: " + JSON.stringify(errorData, null, 2));
        
        // For read operations, try to convert the data even if marked as error
        if (entryType.startsWith('read_') && errorData) {
          try {
            MDS.log("apihandler.js: Attempting to convert error data for read operation");
            // Convert the data to schema format
            let schemaResponse = SchemaConverter.convertLegacyToNewSchema(errorData, coreType);
            MDS.log("apihandler.js: Converted error data: " + JSON.stringify(schemaResponse, null, 2));
            
            if (schemaResponse) {
              MDS.log("apihandler.js: Successfully converted error data, sending response");
              MDS.api.reply(
                msg.data.from,
                msg.data.id,
                JSON.stringify({
                  status: true,
                  response: schemaResponse
                })
              );
              return;
            }
          } catch (conversionError) {
            MDS.log("apihandler.js: Error converting error data: " + conversionError);
          }
        }
        
        // If conversion failed or it's not a read operation, send the error
        MDS.log("apihandler.js: Sending error response");
        MDS.api.reply(
          msg.data.from,
          msg.data.id,
          JSON.stringify({
            status: false,
            error: (response && response.error) || "Unknown error"
          })
        );
        return;
      }

      // For successful responses, convert to schema format
      try {
        MDS.log("apihandler.js: Converting successful response to schema format");
        // Convert response to schema format
        const schemaResponse = SchemaConverter.convertLegacyToNewSchema(
          response, 
          coreType
        );
        
        MDS.log("apihandler.js: Converted schema response: " + JSON.stringify(schemaResponse, null, 2));
        
        MDS.api.reply(
          msg.data.from,
          msg.data.id,
          JSON.stringify({
            status: true,
            response: schemaResponse
          })
        );
      } catch (error) {
        MDS.log("apihandler.js: Error converting successful response: " + error);
        MDS.api.reply(
          msg.data.from,
          msg.data.id,
          JSON.stringify({
            status: false,
            error: "Error converting response: " + error
          })
        );
      }
    };
  },

  // Core functionality methods
  sendMessage: function(params, callback) {
    sendTxnMessage(
      params.category,
      params.title,
      params.message,
      params.user,
      params.pubkey,
      params.address,
      params.randId,
      params.created,
      params.description,
      callback
    );
  },

  sendTip: function(params, callback) {
    sendTxnTip(
      params.userPubkey,
      params.recipientAddr,
      params.recipientPubkey,
      params.randId,
      params.postId,
      params.amount,
      params.isAmp,
      params.isReply,
      callback
    );
  },

  sendPayment: function(params, callback) {
    sendPayment(
      params.senderName,
      params.description,
      params.amount,
      params.coinId,
      callback
    );
  },

  sendPoll: function(params, callback) {
    sendPollMessage(
      params.question,
      params.options,
      params.user,
      params.pubkey,
      params.address,
      params.randId,
      params.created,
      callback
    );
  },

  sendPollVote: function(params, callback) {
    sendPollVote(
      params.pollId,
      params.optionId,
      params.pubkey,
      callback
    );
  },

  readCoin: function(entry, callback) {
    const coin = entry.coin;
    if (!coin) {
      callback({ status: false, error: "Missing coin data" });
      return;
    }

    // Map read operations to appropriate functions
    switch(entry.entryType) {
      case 'read_message':
        readMessageCoin(coin, callback);
        break;
      case 'read_tip':
        readTipCoin(coin, callback);
        break;
      case 'read_poll':
        readPollCoin(coin, callback);
        break;
      case 'read_poll_vote':
        readPollVoteCoin(coin, callback);
        break;
      case 'read_payment':
        readPaymentCoin(coin, callback);
        break;
      default:
        callback({ status: false, error: "Invalid read type" });
    }
  }
};
