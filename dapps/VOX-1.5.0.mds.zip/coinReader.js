/**
 * Coin Reading and Decoding Functions
 * Dependencies:
 * - MDS from Minima
 * - stripBrackets from jslib.js
 * - decodeHexString from utils.js
 */

function decodeMultipleStrings(hexStrings, onComplete) {
  const results = new Array(hexStrings.length);
  let completed = 0;

  hexStrings.forEach((hex, index) => {
    decodeHexString(
      stripBrackets(hex),
      /* isHistorical, */ (decoded) => {
        results[index] = decoded;
        completed++;
        if (completed === hexStrings.length) {
          onComplete(results);
        }
      }
    );
  });
}

function readMessageCoin(coin, /* isHistorical, */ callback) {
  const post_category = stripBrackets(coin.state[0]);
  const post_Id = coin.coinid;

  // Decode all strings that need decoding
  const hexStrings = [
    coin.state[1], // title
    coin.state[2], // message
    coin.state[3], // username
    coin.state[9], // description
  ];

  decodeMultipleStrings(hexStrings, (decodedStrings) => {
    const messageState = {
      id: post_Id,
      category: post_category,
      title: decodedStrings[0],
      message: decodedStrings[1],
      userName: decodedStrings[2],
      randId: stripBrackets(coin.state[4]),
      userPubkey: stripBrackets(coin.state[5]),
      signature: stripBrackets(coin.state[6]),
      address: stripBrackets(coin.state[7]),
      created: stripBrackets(coin.state[8]),
      description: decodedStrings[3],
    };

    callback(messageState);
  });
}

function readTipCoin(coin, callback) {
  // Keep raw value for version check
  const rawIsAmp = stripBrackets(coin.state[7]);
  const isOldVersion = rawIsAmp === "1" || rawIsAmp === "0";

  const tipState = {
    id: coin.coinid,
    userPubkey: stripBrackets(coin.state[0]),
    recipientAddr: stripBrackets(coin.state[1]),
    recipientPubkey: stripBrackets(coin.state[2]),
    randId: stripBrackets(coin.state[3]),
    postId: stripBrackets(coin.state[4]),
    amount: parseFloat(stripBrackets(coin.state[5])),
    signature: stripBrackets(coin.state[6]),
    isAmp: isOldVersion ? rawIsAmp === "1" : rawIsAmp.toUpperCase() === "TRUE",
    isReply: stripBrackets(coin.state[8]).toUpperCase() === "TRUE",
    isOldVersion,
    rawIsAmp,
  };

  callback(tipState);
}

function readPollVoteCoin(coin, callback) {
  const voteState = {
    id: coin.coinid,
    userPubkey: stripBrackets(coin.state[0]),
    pollId: stripBrackets(coin.state[4]),
    optionId: stripBrackets(coin.state[5]),
    randId: stripBrackets(coin.state[3]),
    signature: stripBrackets(coin.state[6]),
  };

  callback(voteState);
}

function readPollCoin(coin, /* isHistorical, */ callback) {

  // Strings that need decoding (message containing poll data, username)
  const hexStrings = [
    coin.state[2], // message (contains poll data)
    coin.state[3], // username
  ];

  decodeMultipleStrings(hexStrings, ([pollDataStr, userName]) => {
    try {
      const { question, options } = JSON.parse(pollDataStr);
      const pollState = {
        id: coin.coinid,
        category: stripBrackets(coin.state[0]),
        question,
        options,
        userName,
        randId: stripBrackets(coin.state[4]),
        userPubkey: stripBrackets(coin.state[5]),
        signature: stripBrackets(coin.state[6]),
        address: stripBrackets(coin.state[7]),
        created: stripBrackets(coin.state[8]),
      };
      callback(pollState);
    } catch (error) {
      MDS.log("ERROR: Error parsing poll data: " + error);
      callback(null);
    }
  });
}

function readReactionCoin(coin, callback) {
  const reactionState = {
    id: coin.coinid,
    userPubkey: stripBrackets(coin.state[3]),
    emoji: stripBrackets(coin.state[2]),
    randId: stripBrackets(coin.state[4]),
    postId: stripBrackets(coin.state[7]),
    signature: stripBrackets(coin.state[6]),
    created: stripBrackets(coin.state[8]),
  };

  callback(reactionState);
}

function readPaymentCoin(coin, callback) {
  const hexStrings = [
    coin.state[1], // sender name
    coin.state[2], // description
  ];

  decodeMultipleStrings(hexStrings, ([senderName, description]) => {
    const paymentState = {
      category: "PAYMENT",
      senderName: senderName,
      description: description,
      amount: stripBrackets(coin.state[4]),
      coinId: coin.coinid,
    };
    
    callback(paymentState);
  });
}
