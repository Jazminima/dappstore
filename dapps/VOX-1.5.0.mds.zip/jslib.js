function cleanCategory(incategory) {
  if (!incategory) {
    return "";
  }

  //Remove spaces
  var newcat = incategory.split(" ").join("");

  //Remove double dots
  while (newcat.indexOf("..") != -1) {
    newcat = newcat.split("..").join(".");
  }

  if (newcat.startsWith(".")) {
    newcat = newcat.substring(1);
  }

  if (newcat.endsWith(".")) {
    newcat = newcat.substring(0, newcat.length - 1);
  }

  newcat = newcat.replace(/<\/?[^>]+(>|$)/g, "");

  return newcat.toLowerCase();
}

function striptags(text) {
  return text.replace(/<\/?[^>]+(>|$)/g, "");
}

function isBaseCategory(zCategory, zCheck) {
  return zCategory == zCheck || zCategory.startsWith(zCheck + ".");
}

function stripBrackets(coinstr) {
  if (!coinstr) {
    return "";
  }

  var str = coinstr.trim();
  if (str.startsWith("[")) {
    str = str.substring(1);
  }

  if (str.endsWith("]")) {
    str = str.substring(0, str.length - 1);
  }

  return str;
}

function cleanMessage(message) {
  let msg = window.DOMPurify.sanitize(message, {
    ALLOWED_TAGS: [
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "p",
      "b",
      "strong",
      "i",
      "em",
      "u",
      "s",
      "blockquote",
      "pre",
      "code",
      "ul",
      "ol",
      "li",
      "br",
      "hr",
      "a",
      "table",
      "thead",
      "tbody",
      "tr",
      "th",
      "td",
      "span",
      "div",
      "sup",
      "sub",
    ],
    ALLOWED_ATTR: {
      a: ["href", "title", "target"],
    },
    ALLOW_ARIA_ATTR: false,
    ALLOW_DATA_ATTR: false,
    ALLOW_UNKNOWN_PROTOCOLS: true,
    ADD_UNICODE_ESCAPES: false,
  });
  return msg.trim();
}

function isChainMessageValid(
  post_Id,
  post_category,
  post_title,
  post_msg,
  post_user,
  post_randId,
  post_userPubkey,
  post_sign
) {
  // Common required fields for all message types
  if (
    post_Id == "" ||
    post_category == "" ||
    post_msg == "" ||
    post_user == "" ||
    post_randId == "" ||
    post_userPubkey == "" ||
    post_sign == ""
  ) {
    return false;
  }

  if (post_category === "REPOST" || post_category === "POLL" || post_category === "REACTION") {
    return true;
  }

  return post_title != "";
}

function isChainTipValid(
  userPubkey,
  recipientAddress,
  randId,
  postId,
  amount,
  isAmp,
  signature
) {
  // For regular tips only
  return (
    userPubkey != "" &&
    recipientAddress != "" &&
    randId != "" &&
    postId != "" &&
    typeof amount === "number" &&
    amount > 0 &&
    isAmp !== undefined &&
    isAmp !== null &&
    signature != ""
  );
}

function isChainPollVoteValid(userPubkey, pollId, optionId, randId, signature) {
  // For poll votes only
  return (
    userPubkey != "" &&
    pollId != "" &&
    optionId != "" &&
    randId != "" &&
    signature != ""
  );
}
