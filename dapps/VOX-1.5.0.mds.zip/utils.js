/**
 * Utility Functions
 * No dependencies other than MDS
 */

function checkTxn(msg) {
  if (msg.data.coin.tokenid != "0x00") {
    MDS.log("Message not sent as Minima.. ! " + msg.data.coin.tokenid);
    return false;
  } else if (stripBrackets(msg.data.coin.state[0]) === "REACTION" || stripBrackets(msg.data.coin.state[0]) === "REPLY_REACTION") {
    if (+msg.data.coin.amount < 0.0001) {
      MDS.log("Message below 0.0001 reaction threshold.. ! " + msg.data.coin.amount);
      return false;
    }
  } else if (+msg.data.coin.amount < 0.01) {
    MDS.log("Message below 0.01 threshold.. ! " + msg.data.coin.amount);
    return false;
  }
  return true;
}

function decodeHexString(hexStr, /* isHistorical, */ callback) {
  if (!hexStr) {
    callback("");
    return;
  }
  try {
    // Check if the string starts with '0x' to determine if it's hex encoded
    if (hexStr.startsWith("0x")) {
      // Use Minima's convert command to convert from HEX to String
      MDS.cmd(`convert from:HEX to:String data:${hexStr}`, function (resp) {
        if (resp.status) {
          const decodedString = decodeURIComponent(resp.response.conversion);
          callback(decodedString);
        } else {
          MDS.log("ERROR: Convert command failed: " + JSON.stringify(resp));
          callback("");
        }
      });
    } else {
      // If not hex encoded, return the original string
      callback(hexStr);
    }
  } catch (e) {
    MDS.log("ERROR: Error decoding string: " + e);
    callback("");
  }
}