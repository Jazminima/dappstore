var TIMER_COUNT = 0;

var getHistoryAndStore = function() {
    MDS.cmd('history', function(response) {
        response.response.txpows.forEach((txpow, index) => {
            const details = response.response.details[index];

            MDS.sql(`SELECT * FROM txpows WHERE txpowid = '${txpow.txpowid}'`, function(result) {
                if (result.rows.length === 0) {
                    MDS.sql(`INSERT INTO txpows (txpowid, timemilli, isblock, istransaction, hasbody, burn, superblock, size, header, body, details) VALUES ('${txpow.txpowid}', ${txpow.header.timemilli}, ${txpow.isblock}, ${txpow.istransaction}, ${txpow.hasbody}, ${txpow.burn}, ${txpow.superblock}, ${txpow.size}, '${JSON.stringify(txpow.header)}', '${JSON.stringify(txpow.body)}','${JSON.stringify(details)}')`)
                }
            });
        });
    });
}

MDS.init(function (msg) {
    if (msg.event === 'inited') {
      MDS.sql('CREATE TABLE IF NOT EXISTS txpows (txpowid TEXT PRIMARY KEY, timemilli BIGINT, isblock BOOLEAN, istransaction BOOLEAN, hasbody BOOLEAN, burn INT, superblock INT, size INT, header TEXT, body TEXT, details TEXT)', function() {
        getHistoryAndStore();
      });
    }

    if (msg.event === 'MDS_TIMER_10SECONDS') {
        TIMER_COUNT++;

        if (TIMER_COUNT >= 2) {
            getHistoryAndStore();
            TIMER_COUNT = 0;
        }
    }
  })